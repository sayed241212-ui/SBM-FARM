package com.sbmfarm.app

import android.app.*
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.view.Gravity
import android.widget.*
import android.graphics.drawable.GradientDrawable

data class Cow(val id:String,val breed:String,val age:String,val weight:String,val price:String,val status:String)

class MainActivity : Activity() {
    private val green = Color.rgb(20,83,45)
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun tv(t:String,s:Float,b:Boolean=false)=TextView(this).apply{
        text=t;textSize=s;setTextColor(Color.DKGRAY);setPadding(dp(8),dp(6),dp(8),dp(6))
        if(b)setTypeface(null,1)
    }
    private val cows = listOf(
        Cow("SBM-001","শাহীওয়াল ষাঁড়","২ বছর ৬ মাস","৪৫০ কেজি","৳ ১,৮৫,০০০","Available"),
        Cow("SBM-002","ফ্রিজিয়ান ক্রস","১ বছর ১০ মাস","৩৮০ কেজি","৳ ১,৪৫,০০০","Available"),
        Cow("SBM-003","দেশি ষাঁড়","৩ বছর","৪২০ কেজি","৳ ২,১০,০০০","Available")
    )
    override fun onCreate(b:Bundle?) { super.onCreate(b); showHome() }

    private fun showHome(){
        val scroll=ScrollView(this)
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(14),dp(16),dp(20))}
        scroll.addView(root)
        root.addView(tv("🐄  SBM FARM",30f,true).apply{setTextColor(green);gravity=Gravity.CENTER})
        root.addView(tv("মানসম্মত গরু • বিশ্বস্ত সেবা",16f).apply{gravity=Gravity.CENTER})
        val search=EditText(this).apply{hint="🔍 গরুর ID / জাত খুঁজুন"}
        root.addView(search)
        root.addView(tv("বিক্রির জন্য গরু",23f,true).apply{setTextColor(green)})
        cows.forEach{ addCow(root,it) }
        root.addView(tv("📊 Farm Management",22f,true).apply{setTextColor(green)})
        val admin=Button(this).apply{text="👨‍🌾 Admin Panel";setOnClickListener{showAdmin()}}
        root.addView(admin)
        val contact=Button(this).apply{text="📞 SBM Farm-এ যোগাযোগ";setOnClickListener{contactWhatsApp()}}
        root.addView(contact)
        setContentView(scroll)
    }

    private fun addCow(root:LinearLayout,c:Cow){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(10),dp(12),dp(10))}
        val bg=GradientDrawable().apply{setColor(Color.rgb(245,249,246));cornerRadius=dp(16).toFloat()}
        box.background=bg
        box.addView(tv("🐂  ${c.breed}",20f,true))
        box.addView(tv("ID: ${c.id}  •  বয়স: ${c.age}  •  ওজন: ${c.weight}",14f))
        box.addView(tv(c.price+"  •  "+if(c.status=="Available")"✅ Available" else "❌ Sold",18f,true).apply{setTextColor(green)})
        box.addView(Button(this).apply{text="বিস্তারিত / Booking";setOnClickListener{showDetails(c)}})
        root.addView(box,LinearLayout.LayoutParams(-1,dp(170)).apply{setMargins(0,dp(7),0,dp(7))})
    }

    private fun showDetails(c:Cow){
        val d=AlertDialog.Builder(this).setTitle("🐄 ${c.breed}")
            .setMessage("গরুর ID: ${c.id}\nজাত: ${c.breed}\nবয়স: ${c.age}\nওজন: ${c.weight}\nমূল্য: ${c.price}\nStatus: ${c.status}\n\nBooking করতে যোগাযোগ করুন।")
            .setPositiveButton("WhatsApp"){_,_->contactWhatsApp()}
            .setNegativeButton("বন্ধ",null).create()
        d.show()
    }

    private fun showAdmin(){
        val msg="""Admin Dashboard

মোট গরু: ৩
Available: ৩
Sold: ০

ফিচার:
• গরু Add / Edit / Delete
• ছবি ও তথ্য
• বিক্রয় Status
• ওজন ও বয়স
• ক্রয়/বিক্রয় মূল্য
• খরচ ও লাভ-ক্ষতি
• টিকা/স্বাস্থ্য রেকর্ড
• Customer Booking

এই Demo-তে UI প্রস্তুত; অনলাইন ডাটাবেস যুক্ত করলে এগুলো বাস্তবে সংরক্ষণ হবে।"""
        AlertDialog.Builder(this).setTitle("👨‍🌾 SBM Farm Admin").setMessage(msg)
            .setPositiveButton("ঠিক আছে",null).show()
    }

    private fun contactWhatsApp(){
        try{
            val url="https://wa.me/8801911552178?text="+Uri.encode("আসসালামু আলাইকুম, SBM Farm-এর গরু সম্পর্কে জানতে চাই।")
            startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(url)))
        }catch(e:Exception){
            Toast.makeText(this,"WhatsApp/ব্রাউজার খুলতে সমস্যা হয়েছে",Toast.LENGTH_SHORT).show()
        }
    }
}
