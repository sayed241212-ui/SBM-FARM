# SBM Farm — Full Android UI Project

পূর্ণাঙ্গ UI prototype:
- Home
- গরুর তালিকা
- Sahiwal bull
- Details
- Booking/WhatsApp
- Admin dashboard UI
- ভবিষ্যৎ database fields: ছবি, বয়স, ওজন, ক্রয়/বিক্রয়, খরচ, লাভ, স্বাস্থ্য/টিকা

APK build:
Android Studio-তে project folder খুলে Gradle Sync করুন, তারপর Build > Build APK(s) নির্বাচন করুন।

নোট: এই project-এ অনলাইন database এখনো সংযুক্ত নয়; এটি production-ready UI foundation।
